# Solutions Notebooks

This directory contains the "solutions notebooks" that can be run without
modification. The "exercises notebooks" (`../exercises/*.ipynb`) are derived
from these notebooks by executing `_generate_notebooks.ipynb`, but the exercise
notebooks are missing some code that should be filled in by the workshop
participants.
