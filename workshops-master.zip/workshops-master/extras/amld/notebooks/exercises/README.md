# Exercises Notebooks

This directory contains the "exercises notebooks" that are automatically
generated from the files with the same name in the directory `../solutions`.
